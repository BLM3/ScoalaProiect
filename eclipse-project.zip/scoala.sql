-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: scoala
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `elevi`
--

DROP TABLE IF EXISTS `elevi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elevi` (
  `id_elev` int NOT NULL AUTO_INCREMENT,
  `nume` varchar(50) DEFAULT NULL,
  `prenume` varchar(55) DEFAULT NULL,
  `adresa` varchar(100) DEFAULT NULL,
  `clasa` varchar(5) NOT NULL,
  PRIMARY KEY (`id_elev`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elevi`
--

LOCK TABLES `elevi` WRITE;
/*!40000 ALTER TABLE `elevi` DISABLE KEYS */;
INSERT INTO `elevi` VALUES (1,'Pop','Ionel','Iasi','9a'),(2,'Popescu','George','Bucuresti','9a'),(3,'Ionescu','Ana','Iasi','9a'),(4,'Vasilescu','Maria','Brasov','9a'),(5,'Ion','Lucian','Timisoara','10b'),(6,'Andrei','Tudor','Iasi','10b'),(7,'Andrei','Vasi','Botosani','10b'),(8,'Mihai','Radu','Bacau','10b'),(9,'Georgescu','Ionut','Suceava','11d'),(10,'Moraru','Alin','Mures','11d'),(11,'Cumpatescu','Eliza','Cluj','11d'),(12,'Frau','Horia','Suceava','11d'),(13,'Ion','Mihai','Brasov','12a'),(14,'Ion','Mihai','Brasov','12a'),(15,'Vasilescu','Elena','Iasi','9a'),(31,'Iordache','Marian','Brasov','9a'),(32,'Andrei','Mihai','Cluj','11d'),(33,'Antonescu','Ana','Cluj','11d'),(34,'Anton','Marian','iasi','9a'),(35,'Vasile','Maria','Iasi','9a'),(36,'Bila','Gheorghe','Iasi','10b'),(37,'Dumitrescu','Bogdan','Iasi','11c');
/*!40000 ALTER TABLE `elevi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materii`
--

DROP TABLE IF EXISTS `materii`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `materii` (
  `id_materie` int NOT NULL AUTO_INCREMENT,
  `denumire` varchar(50) DEFAULT NULL,
  `id_profesor` int DEFAULT NULL,
  PRIMARY KEY (`id_materie`),
  KEY `fk_materie_id_profesor` (`id_profesor`),
  CONSTRAINT `fk_materie_id_profesor` FOREIGN KEY (`id_profesor`) REFERENCES `profesori` (`id_profesor`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materii`
--

LOCK TABLES `materii` WRITE;
/*!40000 ALTER TABLE `materii` DISABLE KEYS */;
INSERT INTO `materii` VALUES (1,'Lb Romana',1),(2,'Matematica',2),(3,'Fizica',3),(4,'Chimie',4),(5,'Sport',5);
/*!40000 ALTER TABLE `materii` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note` (
  `id_nota` int NOT NULL AUTO_INCREMENT,
  `nota` int NOT NULL,
  `data_notei` date DEFAULT NULL,
  `id_elev` int DEFAULT NULL,
  `id_materie` int DEFAULT NULL,
  PRIMARY KEY (`id_nota`),
  KEY `fk_note_id_elev` (`id_elev`),
  KEY `fk_note_id_materie` (`id_materie`),
  CONSTRAINT `fk_note_id_elev` FOREIGN KEY (`id_elev`) REFERENCES `elevi` (`id_elev`),
  CONSTRAINT `fk_note_id_materie` FOREIGN KEY (`id_materie`) REFERENCES `materii` (`id_materie`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
INSERT INTO `note` VALUES (1,6,'2015-10-20',1,1),(2,7,'2015-10-20',2,2),(3,8,'2015-10-20',3,3),(4,9,'2018-09-20',4,5),(5,10,'2018-09-20',5,1),(6,9,'2018-09-20',6,2);
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profesori`
--

DROP TABLE IF EXISTS `profesori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profesori` (
  `id_profesor` int NOT NULL AUTO_INCREMENT,
  `nume` varchar(30) NOT NULL,
  `prenume` varchar(30) NOT NULL,
  PRIMARY KEY (`id_profesor`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profesori`
--

LOCK TABLES `profesori` WRITE;
/*!40000 ALTER TABLE `profesori` DISABLE KEYS */;
INSERT INTO `profesori` VALUES (1,'Ion','Mircea'),(2,'Vasilescu','Ion'),(3,'Ionescu','Gheorghe'),(4,'Anghel','Vasile'),(5,'Andrei','Nicu');
/*!40000 ALTER TABLE `profesori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'scoala'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-18  4:23:36
